<?php
/**
 * Template for displaying all single presenters.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#single-post
 *
 * @package Affinity
 */
function single_presenter_head() {
    echo '<link rel="stylesheet" type="text/css" href="'.get_bloginfo('stylesheet_directory').'/single-presenter.css">'."\n";
}
add_action('wp_head', 'single_presenter_head');
get_header(); ?>

<div id="primary" class="content-area">
    <main id="main" class="site-main" role="main">

        <?php while ( have_posts() ) : the_post();
            get_template_part( 'components/post/content', get_post_format() );
        endwhile; ?>  <!-- end of The Loop -->
        
        <div class="bio-container">
            <img class="bio-photo" src="<?php the_field('photo'); ?>" />
            <p class="bio-header">Biography</p>
            <span class="bio"><?php the_field('bio'); ?></span>
        </div>

        <?php 
            $workshop_ids = get_field('workshop-ids');
            if(count($workshop_ids) > 0) {
                echo '<div class="presenter_page_workshop_info">';
                    echo '<div class="presenter_page_workshop_header">Workshop Information</div>';
                    foreach ($workshop_ids as $workshop_id) {
                        $workshop_name = get_the_title($workshop_id);
                        $workshop_link = get_the_permalink($workshop_id);
                        $workshop_session = get_field('session', $workshop_id);
                        $workshop_location = get_field('room', $workshop_id);
                        echo '<div class="presenter_page_workshop_title">';
                            echo '<a href="' .$workshop_link. '">' .$workshop_name. '</a>';
                        echo '</div>';
                        echo '<div class="presenter_page_workshop_details">';
                            echo '<a href="' . get_site_url(). '/schedule/">Session: ' .$workshop_session. ', Room: ' .$workshop_location. '</a>';
                        echo '</div>';
                    }
                echo '</div>';
            }
        ?>

        <?php the_post_navigation( array( 'prev_text' => '<span class="title">' . esc_html__( 'Previous presenter', 'affinity' ) . '</span>%title', 'next_text' => '<span class="title">' . esc_html__( 'Next presenter', 'affinity' ) . '</span>%title' ) ); ?>
    </main>
</div>
<?php
//get_sidebar();
get_footer();
